package com.cg.cms.dao;

import java.util.*;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;

public class UberDao implements IUberDao
{

	Map<Integer,Cab> cabMap = new HashMap<Integer,Cab>();
	


	@Override
	public void setUberDetails(Cab cab) {
		
		cabMap.put(cab.getCabId(), cab);
	}

	@Override
	public Cab getCabDetails(int cabId) {
		Cab cab=cabMap.get(cabId);
		return cab;
	}

	@Override
	public Map<Integer, Cab> getAllBookingDetails() {
		
		return cabMap;
	}
	
	

}
