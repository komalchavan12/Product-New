
package com.cg.pms.utility;

import java.util.ArrayList;
import java.util.List;

import com.cg.pms.dto.Product;

public class PMSUtil {

	public static List<Product> list = new ArrayList<>();

	static {

		list.add(new Product(111, "TV", 45000d, 24));
		list.add(new Product(222, "AC", 55000d, 14));
		list.add(new Product(333, "Fridge", 25000d, 10));
		list.add(new Product(444, "Mobile", 20000d, 102));
		list.add(new Product(555, "Bike", 75000d, 5));
	}

	public static List<Product> getList() {
		return list;
	}

	public static void setList(List<Product> list) {
		PMSUtil.list = list;
	}

}
